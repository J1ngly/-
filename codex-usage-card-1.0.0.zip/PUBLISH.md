# 发布到 GitHub

本目录已经 `git init` 并提交过（commit `feat: Codex Usage Card plugin for Windows`，tag `v1.0.0`）。只差远端。

## 1. 建仓库

在 GitHub 新建一个空仓库，名字建议 `codex-usage-card`，**不要**勾选 README / .gitignore / license（本地已有）。

## 2. 推上去

HTTPS：

```bash
cd codex-usage-card-repo
git remote add origin https://github.com/<你的账号>/codex-usage-card.git
git branch -M main
git push -u origin main --tags
```

SSH：

```bash
git remote add origin git@github.com:<你的账号>/codex-usage-card.git
git branch -M main
git push -u origin main --tags
```

没有配凭据的话，先在 GitHub → Settings → Developer settings → Personal access tokens 建一个 `repo` 权限的 token，push 时把 token 当密码用。

## 3. 别人怎么装

```bash
codex plugin marketplace add <你的账号>/codex-usage-card
codex plugin add usage-card@codex-usage-card
```

`marketplace add` 支持 `owner/repo[@ref]`、HTTPS/SSH Git URL、本地路径四种源；Git 源会被拉成本地快照，之后 `codex plugin marketplace upgrade codex-usage-card` 可以刷新。

## 4. 发版

改版本号要同时动两处：

- `plugins/usage-card/.codex-plugin/plugin.json` 的 `version`
- `codex plugin add` 之后缓存目录名会跟着变（`~/.codex/plugins/cache/codex-usage-card/usage-card/<version>/`）

```bash
git commit -am "chore: bump 1.1.0"
git tag -a v1.1.0 -m "v1.1.0"
git push --tags
codex plugin marketplace upgrade codex-usage-card
codex plugin add usage-card@codex-usage-card
```

## 5. 打 zip（可选，给不会 git 的人）

在仓库根执行：

```bash
python -c "import zipfile,os;z=zipfile.ZipFile('../codex-usage-card-1.0.0.zip','w',zipfile.ZIP_DEFLATED);[z.write(os.path.join(d,f),os.path.relpath(os.path.join(d,f),'.')) for d,_,fs in os.walk('.') if '.git' not in d for f in fs];z.close()"
```

或直接上传 Release 里的 zip：下载解压后

```bash
codex plugin marketplace add <解压目录>
codex plugin add usage-card@codex-usage-card
```
