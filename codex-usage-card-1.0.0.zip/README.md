# Codex Usage Card · Windows

把 Codex 的用量塞进 Codex 自己：装成插件后，在对话里问一句「看下我现在的用量」，就返回卡片。

- **跟随 cc-switch 切换**：当前走 OpenAI 官方就显示剩余额度（5 小时 / 每周 / 每月，按账号实际返回），走 DeepSeek 就显示账户余额 + token 消耗。
- **零依赖**：MCP 服务器是纯 Node 单文件，不需要 `npm install`。
- **不上传任何数据**：额度读本机 Codex 登录态，余额读 DeepSeek 官方接口，token 由本机会话记录统计。

```
**Codex 用量 · DeepSeek**  `deepseek-flash`

余额 **¥11.84** · 可用
今日 942.5K tok（输入 18.4K · 缓存 920.0K · 输出 4.10K）
近 7 日趋势 `▁▃▅▂▇▁▄`
```

```
**Codex 用量 · OpenAI Codex**  `gpt-6.1-sol` · 套餐 plus

`▰▰▰▰▰▰▰▱▱▱`  **74%** 剩余　5 小时 · 2 小时 9 分后重置
`▰▰▰▰▰▰▰▰▱▱`  **83%** 剩余　每周 · 2 天 23 小时后重置
今日 1.15M tok · 近 7 日 10.2M tok
```

## 安装

### 方式 A：从 GitHub 市场装（推荐）

```bash
codex plugin marketplace add <你的账号>/codex-usage-card
codex plugin add usage-card@codex-usage-card
```

`codex` = Codex 自带 CLI：`%LOCALAPPDATA%\OpenAI\Codex\bin\<hash>\codex.exe`（也可以先用 `where codex` 试）。

### 方式 B：从 zip 装

1. 下载 `codex-usage-card-1.0.0.zip` 并解压到任意目录，例如 `D:\codex-usage-card`。
2. 注册这个目录为本地市场并安装：

```bash
codex plugin marketplace add D:\codex-usage-card
codex plugin add usage-card@codex-usage-card
```

### 方式 C：直接 clone

```bash
git clone https://github.com/<你的账号>/codex-usage-card.git
codex plugin marketplace add ./codex-usage-card
codex plugin add usage-card@codex-usage-card
```

装完 **重启 Codex 客户端**（插件在启动时加载）。

## 用

对话里说：

- 「看下我现在的用量」
- 「DeepSeek 还剩多少余额」
- 「今天用了多少 token」
- 「GPT 那边额度还剩多少」→ 强制读 OpenAI 侧

工具 `get_usage` 支持 `provider: auto | gpt | deepseek`；`get_usage_json` 返回原始快照（含近 7 日序列），方便让 Codex 画图。

## 卸载

```bash
codex plugin remove usage-card@codex-usage-card
codex plugin marketplace remove codex-usage-card
```

## 数据从哪来

| 数据 | 来源 |
| --- | --- |
| OpenAI 剩余额度 | `codex.exe app-server` → `account/rateLimits/read`（用 `~/.codex/auth.json` 登录态） |
| DeepSeek 余额 | `GET https://api.deepseek.com/user/balance`（Key 取自 `~/.codex/config.toml` 里指向 deepseek 的 provider，或 `DEEPSEEK_API_KEY`） |
| Token 用量 | `~/.codex/sessions/**/rollout-*.jsonl` 的 `token_usage_record`，按模型分桶，增量缓存 |

只读配置与会话统计字段，不读对话内容。日志写在 `%LOCALAPPDATA%\codex-usage-card\plugin.log`（含启动时间、cwd、node 路径，用于排错）。

## 目录

```
.agents/plugins/marketplace.json   市场清单（本仓库根 = marketplace 根）
plugins/usage-card/
  .codex-plugin/plugin.json        插件元数据
  .mcp.json                        MCP 声明（cwd 用相对路径 "."，装到哪都能跑）
  launch.cmd                       启动器：按 PATH → Codex 自带 node → 常见安装位置 找 Node
  server.cjs                       MCP 服务器（stdio，纯 Node）
  lib/                             额度 / 余额 / token 统计
  skills/usage-card/SKILL.md       告诉 Codex 何时调用
  assets/icon.png
```

## 排错

| 现象 | 处理 |
| --- | --- |
| 装完重启仍无该工具 | `codex plugin list` 看是否 `installed, enabled`；`codex mcp list` 看 `usage_card` 是否在 |
| 工具被审批拦截 | `.mcp.json` 已声明 `default_tools_approval_mode: "approve"`；若被全局策略覆盖，在 Codex 里放行一次 |
| 余额显示「不可用」 | `config.toml` 里 DeepSeek Key 是否有效；或设 `DEEPSEEK_API_KEY` |
| 额度一直没有数字 | 账号需为已登录的 ChatGPT 账号；免费档只有「每月」一个窗口 |
| 想看启动过程 | `%LOCALAPPDATA%\codex-usage-card\plugin.log` |

## 限制

- 只做了 Windows 的启动器（`launch.cmd`）；macOS/Linux 需要把 `.mcp.json` 的 `command` 改成 `node`，`args` 改成 `["server.cjs"]` 并自备 Node。
- 卡片是「问一次拉一次」，不是常驻控件。Windows 上无法注入客户端侧栏（MSIX 包不允许带参数启动、包内文件签名保护），所以走官方插件位。
- ChatGPT 免费档只返回一个额度窗口；Plus/Pro 才有 5 小时 + 每周两条。

## License

MIT
