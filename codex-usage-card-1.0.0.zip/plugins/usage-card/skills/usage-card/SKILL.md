---
name: "Usage Card"
description: "Display the user's Codex usage: remaining OpenAI quota windows (5h / weekly / monthly), DeepSeek account balance, and locally counted token totals for the provider cc-switch currently routes to. Use whenever the user asks about 用量、额度、剩余、还剩多少、余额、token 消耗、跑了多少 token、rate limit、quota、usage、balance."
---

# Usage Card

调用本插件的 `get_usage` 工具，把返回的卡片**原样**输出给用户（保留 Markdown 与进度条字形），不要改写成散句，也不要补充猜测的数字。

## 何时调用

- 用户问「用量多少 / 还剩多少额度 / 额度用完了吗 / 什么时候重置」
- 用户问「DeepSeek 余额 / 账户还有多少钱」
- 用户问「今天/这周用了多少 token」
- 用户在做成本判断、需要知道当前走的是哪家供应商时

## 参数

- `provider` 省略或 `auto`：跟随当前 `~/.codex/config.toml` 的配置（默认）
- `provider: "gpt"`：即使当前在 DeepSeek 模式，也强制读 OpenAI 账号额度
- `provider: "deepseek"`：强制读 DeepSeek 余额与 token

## 注意

- 数字来自本机：额度走 `codex app-server` 的 `account/rateLimits/read`，余额走 DeepSeek 官方接口，token 由 `~/.codex/sessions` 的会话记录统计。
- 若工具返回「余额不可用」或「额度不可用」，把原因一并转述，不要自己编造数值。
- 想给用户看历史趋势时，可调用 `get_usage_json` 取 `series`（近 7 日总量），再用可视化方式呈现。
