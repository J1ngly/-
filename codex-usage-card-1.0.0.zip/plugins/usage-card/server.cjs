#!/usr/bin/env node
'use strict';
// Codex Usage Card 插件 —— 本机 MCP 服务器（stdio，无第三方依赖）
// 提供 get_usage / get_usage_json 两个工具，数据全部来自本机：
//   · OpenAI 额度：codex.exe app-server 的 account/rateLimits/read
//   · DeepSeek 余额：api.deepseek.com/user/balance
//   · token 用量：~/.codex/sessions 的 rollout 记录（增量缓存）

const readline = require('node:readline');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const { snapshot } = require('./lib/collect');

const VERSION = '1.0.0';
const LOCAL_DIR = path.join(
  process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'),
  'codex-usage-card'
);
const CACHE_DIR = path.join(LOCAL_DIR, 'plugin-cache');

// 轻量启动日志：排查「插件没被调用」时看这个文件
function logStartup() {
  try {
    fs.mkdirSync(LOCAL_DIR, { recursive: true });
    const line = `[${new Date().toISOString()}] start pid=${process.pid} cwd=${process.cwd()} node=${process.execPath} server=${__filename}\n`;
    fs.appendFileSync(path.join(LOCAL_DIR, 'plugin.log'), line);
  } catch {}
}
logStartup();

const TOOLS = [
  {
    name: 'get_usage',
    title: '查看当前用量',
    description:
      '查看 Codex 当前供应商的用量：OpenAI 账号返回 5 小时/每周/每月剩余额度与重置时间，DeepSeek 返回账户余额与 token 消耗，其它供应商返回本地统计的 token 用量。当用户问「用量」「还剩多少额度」「余额」「token 用了多少」时调用。',
    inputSchema: {
      type: 'object',
      properties: {
        provider: {
          type: 'string',
          enum: ['auto', 'gpt', 'deepseek'],
          description: 'auto=跟随当前 Codex 配置（默认）；gpt/deepseek 可强制查看另一侧',
        },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'get_usage_json',
    title: '用量原始数据',
    description: '以 JSON 返回当前用量快照，便于做图表或二次处理。',
    inputSchema: {
      type: 'object',
      properties: {
        provider: { type: 'string', enum: ['auto', 'gpt', 'deepseek'] },
      },
      additionalProperties: false,
    },
  },
];

// ---------- 格式化 ----------
function fmt(n) {
  n = Number(n || 0);
  if (!isFinite(n)) return '--';
  if (n < 1000) return String(Math.round(n));
  if (n < 1e6) return (n / 1e3).toFixed(n < 1e4 ? 1 : 1) + 'K';
  if (n < 1e9) return (n / 1e6).toFixed(2) + 'M';
  return (n / 1e9).toFixed(2) + 'B';
}

function bar(pct, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((pct / 100) * width)));
  return '▰'.repeat(filled) + '▱'.repeat(width - filled);
}

function relTime(unixSec) {
  if (!unixSec) return '';
  const ms = unixSec * 1000 - Date.now();
  if (ms <= 0) return '可重置';
  const mins = Math.floor(ms / 60000);
  if (mins < 60) return `${Math.max(1, mins)} 分钟后重置`;
  const h = Math.floor(mins / 60);
  if (h < 24) return `${h} 小时 ${mins % 60} 分后重置`;
  return `${Math.floor(h / 24)} 天 ${h % 24} 小时后重置`;
}

function spark(series) {
  const chars = '▁▂▃▄▅▆▇█';
  const max = Math.max(1, ...series.map((s) => s.total || 0));
  return series
    .map((s) => (s.total ? chars[Math.min(7, Math.floor(Math.sqrt(s.total / max) * 7.99))] : '·'))
    .join('');
}

function formatUsage(s) {
  const lines = [];
  const head = `**Codex 用量 · ${s.label}**`;
  const meta = [s.model ? `\`${s.model}\`` : '', s.plan ? `套餐 ${s.plan}` : '', s.forced ? '（手动查看另一侧）' : '']
    .filter(Boolean)
    .join(' · ');
  lines.push(head + (meta ? '  ' + meta : ''));
  lines.push('');

  if (s.mode === 'gpt') {
    const q = s.quota || {};
    const wins = [q.primary, q.secondary].filter(Boolean);
    if (wins.length) {
      for (const w of wins) {
        lines.push(
          `\`${bar(w.remainingPercent)}\`  **${Math.round(w.remainingPercent)}%** 剩余　${w.windowLabel} · ${relTime(w.resetsAt)}`
        );
      }
    } else if (s.errors && s.errors.length) {
      lines.push(`额度不可用：${s.errors.join('；')}`);
    } else {
      lines.push('当前账号没有返回额度窗口数据。');
    }
  } else if (s.mode === 'deepseek') {
    const b = s.balance;
    if (b && b.ok) {
      lines.push(`余额 **${b.currency === 'CNY' ? '¥' : b.currency + ' '}${b.total.toFixed(2)}** · ${b.available ? '可用' : '不可用'}`);
    } else {
      lines.push(`余额不可用：${(b && b.error) || '未找到 API Key'}`);
    }
  }

  const t = s.tokens || {};
  const today = t.today || {};
  const week = t.d7 || {};
  if (s.mode === 'deepseek') {
    lines.push(
      `今日 ${fmt(today.total)} tok（输入 ${fmt(today.in)} · 缓存 ${fmt(today.cached)} · 输出 ${fmt(today.out)}）`
    );
  } else if (s.mode === 'other') {
    lines.push(`今日 ${fmt(today.total)} tok · 近 7 日 ${fmt(week.total)} tok · 请求 ${week.reqs || 0} 次`);
  } else {
    lines.push(`今日 ${fmt(today.total)} tok · 近 7 日 ${fmt(week.total)} tok`);
  }
  if (Array.isArray(s.series) && s.series.length && s.series.some((x) => x.total > 0)) {
    lines.push(`近 7 日趋势 \`${spark(s.series)}\``);
  }
  lines.push('');
  lines.push(
    s.mode === 'gpt'
      ? '_额度来自本机 Codex 登录态；token 由本机会话记录统计。_'
      : s.mode === 'deepseek'
        ? '_余额来自 DeepSeek 官方接口；token 由本机会话记录统计。_'
        : '_token 由本机会话记录统计。_'
  );
  return lines.join('\n');
}

// ---------- MCP 管道 ----------
let queue = Promise.resolve();

function callSnapshot(args) {
  const provider = args && args.provider && args.provider !== 'auto' ? args.provider : null;
  queue = queue.then(
    () => snapshot({ cacheDir: CACHE_DIR, force: true, modeOverride: provider }),
    () => snapshot({ cacheDir: CACHE_DIR, force: true, modeOverride: provider })
  );
  return queue;
}

async function handleTool(name, args) {
  if (name === 'get_usage' || name === 'get_usage_json') {
    const snap = await callSnapshot(args || {});
    if (name === 'get_usage_json') {
      const { tokens, series, allTotals, raw, ...rest } = snap;
      return { text: JSON.stringify({ ...rest, tokens: { today: tokens && tokens.today, d7: tokens && tokens.d7, d30: tokens && tokens.d30 }, series }, null, 2) };
    }
    return { text: formatUsage(snap) };
  }
  throw new Error('未知工具：' + name);
}

function send(msg) {
  process.stdout.write(JSON.stringify(msg) + '\n');
}

function reply(id, result) {
  send({ jsonrpc: '2.0', id, result });
}

function replyError(id, code, message) {
  send({ jsonrpc: '2.0', id, error: { code, message } });
}

const rl = readline.createInterface({ input: process.stdin });
rl.on('line', async (line) => {
  const text = line.trim();
  if (!text) return;
  let msg;
  try {
    msg = JSON.parse(text);
  } catch {
    return;
  }
  const { id, method, params } = msg;
  const isRequest = id !== undefined && id !== null;

  try {
    switch (method) {
      case 'initialize':
        reply(id, {
          protocolVersion: (params && params.protocolVersion) || '2025-06-18',
          capabilities: { tools: { listChanged: false }, resources: {} },
          serverInfo: { name: 'usage-card', version: VERSION },
          instructions:
            '当用户询问 Codex / DeepSeek 的用量、剩余额度、余额或 token 消耗时，调用 get_usage 并把返回的卡片原样展示给用户。',
        });
        break;
      case 'notifications/initialized':
      case 'notifications/cancelled':
        break;
      case 'ping':
        if (isRequest) reply(id, {});
        break;
      case 'tools/list':
        reply(id, { tools: TOOLS });
        break;
      case 'resources/list':
        reply(id, { resources: [] });
        break;
      case 'prompts/list':
        reply(id, { prompts: [] });
        break;
      case 'tools/call': {
        const name = params && params.name;
        const args = (params && params.arguments) || {};
        try {
          const out = await handleTool(name, args);
          reply(id, { content: [{ type: 'text', text: out.text }], isError: false });
        } catch (e) {
          reply(id, {
            content: [{ type: 'text', text: '用量读取失败：' + (e && e.message ? e.message : String(e)) }],
            isError: true,
          });
        }
        break;
      }
      default:
        if (isRequest) replyError(id, -32601, 'Method not found: ' + method);
    }
  } catch (e) {
    if (isRequest) replyError(id, -32603, String((e && e.message) || e));
  }
});

process.on('uncaughtException', (e) => {
  process.stderr.write('[usage-card] ' + (e && e.stack ? e.stack : e) + '\n');
});
process.on('unhandledRejection', (e) => {
  process.stderr.write('[usage-card] unhandled ' + (e && e.stack ? e.stack : e) + '\n');
});
