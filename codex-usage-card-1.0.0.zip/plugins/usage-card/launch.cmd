@echo off
rem Resolve a Node.js runtime, then start the usage-card MCP server.
setlocal enabledelayedexpansion
set "SERVER=%~dp0server.cjs"
set "NODE="

rem 1) PATH
for %%I in (node.exe) do if not defined NODE if not "%%~$PATH:I"=="" set "NODE=%%~$PATH:I"

rem 2) Codex bundled node (runtimes\cua_node\<hash>\bin\node.exe)
if not defined NODE (
  for /d %%D in ("%LOCALAPPDATA%\OpenAI\Codex\runtimes\cua_node\*") do (
    if exist "%%~D\bin\node.exe" set "NODE=%%~D\bin\node.exe"
  )
)

rem 3) Common install locations
if not defined NODE if exist "%ProgramFiles%\nodejs\node.exe" set "NODE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE if exist "%LOCALAPPDATA%\Programs\nodejs\node.exe" set "NODE=%LOCALAPPDATA%\Programs\nodejs\node.exe"

rem 4) WorkBuddy bundled node (this machine)
if not defined NODE (
  for /d %%D in ("%USERPROFILE%\.workbuddy\binaries\node\versions\*") do (
    if exist "%%~D\node.exe" set "NODE=%%~D\node.exe"
  )
)

if not defined NODE (
  echo [usage-card] Node.js not found. Install Node 18+ or run Codex once. 1>&2
  exit /b 1
)

"%NODE%" "%SERVER%"
